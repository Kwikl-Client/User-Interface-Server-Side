import { Stripe } from "stripe";
import customerModel from "../models/customerModel.js";
import { generate } from "generate-password";
import sendMail from "../utils/sendMail.js";
import { encrypt } from "../utils/hasher.js";

const productPrice = 80000;

export const payment = async(req, res)=>{
  const stripe = new Stripe(process.env.STRIPE_SECRET);
  try {
    let { name, email } = req.body;
    const existingMember = await customerModel.findOne({ email: email});
    if (existingMember && existingMember.isPaid)
      return res.status(400).json({ success: false, message: `Customer Already Exist and paid already`, data: null });

    const password = generate({ length: 10, numbers: true  });
    await sendMail(email, "Wonted Password", `Your password is ${password}`)
    const hashedPwd = await encrypt(password);

    const newEntry = { name, email, password: hashedPwd};
    // create entry in db
    const newCustomer = await customerModel.create(newEntry);

    const session = await stripe.checkout.sessions.create({
      payment_method_types: ["card"],
      line_items: [
        {
          price_data: {
            currency: "inr",
            product_data: {
              name: "Dummy Product",
            },
            unit_amount: productPrice, // Dummy price in cents (100.00 in INR)
          },
          quantity: 1, // Quantity of the dummy item
        },
      ],
      mode: "payment",
      success_url: "http://localhost:3000/success?session_id={CHECKOUT_SESSION_ID}",
      cancel_url: "http://localhost:3000/cancel",
    });

    console.log("Created session with ID:", session.id); // Add this log
    newCustomer.isPaid = true;
    const updatedCustomer = await newCustomer.save();
    return res.status(201).json({
      success: true,
      message: 'Id created successfully',
      data: {
        paymentId: session.id,
        customer: updatedCustomer
      },
    });
  } catch (error) {
    console.error("Error creating session:", error); // Add this log
    res.status(500).json({ error: error.message });
  }
};
